console.log("hello")

function submit(){
    
    let firstnamedom = document.querySelector( 'input[name=firstname]' )
    let lastnamedom = document.querySelector( 'input[name=lastname]' )
    let agedom = document.querySelector( 'input[name=age]' )
    let genderDom =document.querySelector('input[ name=gender ]:checked')
    let interestDoms = document.querySelectorAll(' input[name=interest]:checked ')
    let descriptiondom = document.querySelector( 'textarea[name=description]' )
    let interest = ''
    for(let i=0;i<interestDoms.length;i++){
        interest+= interestDoms[i].value
        if(i+1<interestDoms.length){
            interest+=', ';
        }
    }
    let userdata ={
        firstname: firstnamedom.value,
        lastname: lastnamedom.value,
        age: agedom.value,
        gender: genderDom.value,
        description: descriptiondom.value,
        interests: interest
    }
    console.log(userdata)
}